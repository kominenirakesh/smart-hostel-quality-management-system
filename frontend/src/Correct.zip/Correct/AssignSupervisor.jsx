import React, { useEffect, useState } from "react";
import api from "../../services/GobalApi";
import "./AssignSupervisorWorkspace.css";

const AssignSupervisor = () => {
  const [hostels,setHostels]=useState([]);
  const [supervisors,setSupervisors]=useState([]);
  const [selectedSupervisor,setSelectedSupervisor]=useState({});
  const [loading,setLoading]=useState(true);
  const [assigningId,setAssigningId]=useState(null);

  const token=sessionStorage.getItem("token");

  useEffect(()=>{fetchData();},[]);

  const fetchData=async()=>{
    try{
      setLoading(true);
      const [dashboardRes,supervisorRes]=await Promise.all([
        api.get("/dashboard/owner",{headers:{Authorization:token}}),
        api.get("/users/supervisors",{headers:{Authorization:token}})
      ]);
      setHostels(dashboardRes.data.data.hostelAnalytics);
      setSupervisors(supervisorRes.data.data);
    }catch(err){
      console.error(err);
      alert(err.response?.data?.message||"Failed to load data.");
    }finally{
      setLoading(false);
    }
  };

  const handleAssign=async(hostelId)=>{
    const supervisorId=selectedSupervisor[hostelId];
    if(!supervisorId){alert("Please select a supervisor.");return;}
    try{
      setAssigningId(hostelId);
      await api.patch(`/hostels/${hostelId}/assign-supervisor`,{supervisorId},{headers:{Authorization:token}});
      alert("Supervisor assigned successfully.");
      fetchData();
    }catch(err){
      console.error(err);
      alert(err.response?.data?.message||"Assignment failed.");
    }finally{
      setAssigningId(null);
    }
  };

  if(loading){
    return <div className="workspace-card"><div className="workspace-header"><h2>Assign Supervisor</h2><p>Loading...</p></div></div>;
  }

  return (
    <div className="workspace-card">
      <div className="workspace-header">
        <h2>👨‍💼 Assign Supervisor</h2>
        <p>Select an available supervisor for each hostel.</p>
      </div>

      <div className="workspace-form">
        {hostels.map((hostel)=>(
          <div key={hostel.hostelId} className="hostel-success-card">
            <div className="success-banner">{hostel.hostelName}</div>

            <div className="hostel-details-grid">
              <div className="detail-box"><span>City</span><strong>{hostel.city}</strong></div>
              <div className="detail-box"><span>Students</span><strong>{hostel.totalStudents}</strong></div>
              <div className="detail-box"><span>Complaints</span><strong>{hostel.totalComplaints}</strong></div>
              <div className="detail-box"><span>Supervisor</span><strong>{hostel.supervisor?hostel.supervisor.name:"Not Assigned"}</strong></div>
            </div>

            {!hostel.supervisor ? (
              <div className="management-note">
                <label><strong>Select Supervisor</strong></label>
                <select
                  value={selectedSupervisor[hostel.hostelId]||""}
                  onChange={(e)=>setSelectedSupervisor(prev=>({...prev,[hostel.hostelId]:e.target.value}))}
                >
                  <option value="">Choose Supervisor</option>
                  {supervisors.map(sup=>(
                    <option key={sup._id} value={sup._id}>{sup.name} ({sup.email})</option>
                  ))}
                </select>

                <button className="primary-btn" onClick={()=>handleAssign(hostel.hostelId)} disabled={assigningId===hostel.hostelId}>
                  {assigningId===hostel.hostelId?"Assigning...":"Assign Supervisor"}
                </button>
              </div>
            ):(
              <div className="management-note">✅ Supervisor already assigned.</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AssignSupervisor;
