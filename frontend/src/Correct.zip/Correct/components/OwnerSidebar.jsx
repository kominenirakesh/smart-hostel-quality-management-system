import React from "react";
import {
  Building2,
  UserCog,
  Users
} from "lucide-react";

const OwnerSidebar = ({ activeTab, setActiveTab }) => {

  const menus = [
    {
      id: "create-hostel",
      label: "Create Hostel",
      icon: <Building2 size={20} />,
    },
    {
      id: "assign-supervisor",
      label: "Assign Supervisor",
      icon: <UserCog size={20} />,
    },
    {
      id: "students",
      label: "Students",
      icon: <Users size={20} />,
    },
  ];

  return (
    <aside className="owner-sidebar">

      <div className="sidebar-header">
        <h2>Management</h2>
        <p>Owner Operations</p>
      </div>

      <div className="sidebar-menu">

        {menus.map((menu) => (
          <button
            key={menu.id}
            className={
              activeTab === menu.id
                ? "sidebar-btn active"
                : "sidebar-btn"
            }
            onClick={() => setActiveTab(menu.id)}
          >
            {menu.icon}
            <span>{menu.label}</span>
          </button>
        ))}

      </div>

    </aside>
  );
};

export default OwnerSidebar;
